#dpkg-deb -Zgzip -b LittleX

dpkg-deb -b LittleX
dpkg-deb -Zgzip -b LittleX